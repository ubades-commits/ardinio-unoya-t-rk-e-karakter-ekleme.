# Türkçe LED yazı
Arduino Uno R3 ve harici, MAX7219 sürücülü FC-16 nokta matris için örnek. Yazı tipine Ç ç Ğ ğ İ ı Ö ö Ş ş Ü ü eklenir. Normal I ve i, Parola'nın kendi yazı tipinden gelir.

## İlk çalıştırma
1. Arduino IDE Kütüphane Yöneticisi'nden MD_Parola ve MD_MAX72XX kütüphanelerini kur.
2. Taslak (Sketch) → Kütüphane Ekle → .ZIP Kitaplığı Ekle menüsünden TurkceLed.zip dosyasını seç.
3. Güç kapalıyken modülün giriş (IN) tarafında DIN'i Uno D11'e, CLK'yi D13'e, CS/LOAD'u D10'a bağla. Modülü uygun 5 V beslemeden besle ve GND'yi Uno GND ile birleştir.
4. Dosya → Örnekler → TurkceLed → KayanYazi örneğini aç. modulSayisi değerini art arda bağlı 8×8 blok sayısına göre ayarla. Dört bloklu tek kart için 4 yaz.
5. Kart olarak Arduino Uno'yu ve kartın bağlı olduğu portu seçip yükle. Kayan yazıyı değiştirmek için mesaj değişkenini düzenle.

## Mevcut bir Parola projesinde kullanım
Örnekteki gibi TurkceLed.h başlığını ekle. Kendi ekran tanımını, bağlantı pinlerini ve donanım tipini koru. ekran.begin() sonrasında bir kez TurkceLed::baslat(ekran) çağır. UTF-8 metni TurkceLed::cevir(metin, tampon, kapasite) ile dönüştürüp tamponu displayText'e ver. Animasyon bitene kadar tampon bellekte kalmalı. Aynı ekranda 1–12 karakter kodları Türkçe harflere ayrılır.

Her harf bir çıkış baytı kullanır. Sonlandırıcı için bir bayt daha ayır. cevir, çıktı sığarsa true döndürür. Yer yetmezse sığan kısmı yazar ve false döndürür. Desteklenen metin, yazdırılabilir ASCII ve yukarıdaki tek kod noktalı Türkçe harflerden oluşur. Örneğin ğ harfini doğrudan yaz. Desteklenmeyen Unicode karakterleri ekranda ? olarak görünür.
