#include <TurkceLed.h>

// UNO R3, MAX7219 FC-16. Dört adet 8×8 matris için 4, tek matris için 1.
const uint8_t modulSayisi = 4;
MD_Parola ekran(MD_MAX72XX::FC16_HW, 11, 13, 10, modulSayisi); // DIN, CLK, CS
const char mesaj[] = "İzmir ışıl ışıl! Çç Ğğ İı Öö Şş Üü";
char yazi[sizeof(mesaj)];

void setup() {
  ekran.begin();
  TurkceLed::baslat(ekran);
  ekran.setIntensity(1);
  TurkceLed::cevir(mesaj, yazi, sizeof(yazi));
  ekran.displayText(yazi, PA_LEFT, 65, 0, PA_SCROLL_LEFT, PA_SCROLL_LEFT);
}

void loop() {
  if (ekran.displayAnimate()) ekran.displayReset();
}
