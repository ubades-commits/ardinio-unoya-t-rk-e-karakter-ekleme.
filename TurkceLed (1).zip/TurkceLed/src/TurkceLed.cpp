#include "TurkceLed.h"

namespace {
struct Glif {
  uint16_t unicode;
  uint8_t sutunlar[6];
};
const Glif glifler[] = {
#include "Glifler.inc"
};
const size_t adet = sizeof(glifler) / sizeof(glifler[0]);

uint8_t sonraki(const uint8_t*& p) {
  uint8_t ilk = *p++;
  if (ilk < 0x80) return ilk >= 32 && ilk < 127 ? ilk : ' ';
  if (ilk < 0xC2 || ilk > 0xF4) return '?';
  uint8_t kalan = ilk < 0xE0 ? 1 : (ilk < 0xF0 ? 2 : 3);
  uint16_t kod = ilk & 31;
  for (uint8_t i = 0; i < kalan; ++i) {
    if ((*p & 0xC0) != 0x80) return '?';
    if (kalan == 1) kod = (kod << 6) | (*p & 63);
    ++p;
  }
  if (kalan == 1) {
    for (size_t i = 0; i < adet; ++i)
      if (glifler[i].unicode == kod) return i + 1;
  }
  return '?';
}
}

void TurkceLed::baslat(MD_Parola& ekran) {
  for (size_t i = 0; i < adet; ++i)
    ekran.addChar(i + 1, glifler[i].sutunlar);
}

bool TurkceLed::cevir(const char* metin, char* hedef, size_t kapasite) {
  if (!hedef || kapasite == 0) return false;
  if (!metin) { hedef[0] = 0; return false; }
  const uint8_t* p = reinterpret_cast<const uint8_t*>(metin);
  size_t n = 0;
  while (*p && n < kapasite - 1) hedef[n++] = sonraki(p);
  hedef[n] = 0;
  return *p == 0;
}
