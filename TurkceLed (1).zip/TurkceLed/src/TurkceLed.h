#pragma once
#include <MD_Parola.h>

namespace TurkceLed {
  // Ekranın begin() çağrısından sonra bir kez çağırın.
  void baslat(MD_Parola& ekran);
  // Tampon dolarsa kısaltır, sonuna sıfır koyar ve false döndürür.
  bool cevir(const char* metin, char* hedef, size_t kapasite);
}
